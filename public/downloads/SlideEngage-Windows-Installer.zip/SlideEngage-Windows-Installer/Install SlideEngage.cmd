@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-slideengage.ps1"
pause
