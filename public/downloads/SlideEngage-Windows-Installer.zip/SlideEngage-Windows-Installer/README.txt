SlideEngage PowerPoint Add-in for Windows

1. Close PowerPoint.
2. Double-click "Install SlideEngage.cmd".
3. Restart PowerPoint.
4. Open Insert > Add-ins > My Add-ins and choose SlideEngage.

The manifest SourceLocation is https://slide-engage.vercel.app/taskpane
