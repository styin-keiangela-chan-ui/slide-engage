@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-slideengage.ps1"
pause
