SlideEngage PowerPoint Add-in for Windows

1. Close PowerPoint.
2. Double-click "Install SlideEngage.cmd".
3. The installer clears old SlideEngage Office cache entries.
4. The installer validates manifest.xml.
5. The installer registers a current-user trusted Office add-in catalog.
6. The installer copies manifest files to the trusted catalog and PowerPoint WEF locations.
7. Restart PowerPoint.
8. Open the Home tab and click "Open SlideEngage" in the SlideEngage group.
9. If the SlideEngage group is not visible, check Insert > My Add-ins or Home > Add-ins.

The manifest includes VersionOverridesV1_0, AddinCommands 1.1, Host Name=Presentation, and a ShowTaskpane ribbon button for https://slide-engage.vercel.app/taskpane.
