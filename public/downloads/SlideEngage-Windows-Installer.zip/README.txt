SlideEngage PowerPoint Add-in for Windows

1. Close PowerPoint.
2. Double-click "Install SlideEngage.cmd".
3. The installer validates manifest.xml.
4. The installer copies manifest.xml to:
   %LOCALAPPDATA%SlideEngageOfficeAddinmanifest.xml
   %LOCALAPPDATA%MicrosoftOffice.0WefSlideEngagemanifest.xml
5. Restart PowerPoint.
6. Open the SlideEngage ribbon tab and click "Open SlideEngage".
7. If the SlideEngage tab is not visible, check Insert > My Add-ins or Home > Add-ins and choose SlideEngage.

If installation fails, the installer opens a diagnostics page showing the manifest path, validation result, and registration status.
