SlideEngage PowerPoint Add-in for Windows

1. Close PowerPoint.
2. Double-click "Install SlideEngage.cmd".
3. The installer clears old SlideEngage Office cache entries.
4. The installer validates manifest.xml.
5. The installer registers a current-user trusted Office add-in catalog.
6. The installer copies manifest files to:
   %LOCALAPPDATA%SlideEngageOfficeAddinmanifest.xml
   %LOCALAPPDATA%MicrosoftOffice.0WefSlideEngagemanifest.xml
   %LOCALAPPDATA%MicrosoftOffice.0WefSlideEngageSlideEngage.xml
   %LOCALAPPDATA%MicrosoftOffice.0WefSlideEngage.xml
7. Restart PowerPoint.
8. Open the SlideEngage ribbon tab and click "Open SlideEngage".
9. If the SlideEngage tab is not visible, check Insert > My Add-ins or Home > Add-ins.

Trusted catalog registry:
HKCUSoftwareMicrosoftOffice.0WEFTrustedCatalogs{3A58A707-8F47-4B13-A3AC-99D9F7238A41}

If PowerPoint still does not show SlideEngage, confirm the catalog is listed in File > Options > Trust Center > Trust Center Settings > Trusted Add-in Catalogs.
